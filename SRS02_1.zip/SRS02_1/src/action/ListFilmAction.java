package action;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.ListFilmForm;
import model.bean.FilmName;
import model.bean.LiberationTime;
import model.bean.Character;
import model.bean.Film;
import model.bo.CharacterBO;
import model.bo.FilmBO;
import model.bo.FilmNameBO;
import model.bo.LiberationTimeBO;
import model.dao.FilmDAO;


public class ListFilmAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ListFilmForm listFilmForm = (ListFilmForm) form;
		
		FilmNameBO filmNameBO = new FilmNameBO();
		ArrayList<FilmName> listFilmName = filmNameBO.getListFilmName();
		listFilmForm.setListFilmName(listFilmName);
		
		CharacterBO characterBO = new CharacterBO();
		ArrayList<Character> listCharacter = characterBO.getListCharacter();
		listFilmForm.setListCharacter(listCharacter);
		
		LiberationTimeBO liberationTimeBO = new LiberationTimeBO();
		ArrayList<LiberationTime> listLiberationTime = liberationTimeBO.getListLiberationTime();
		listFilmForm.setListLiberationTime(listLiberationTime);
		
		FilmBO filmBO = new FilmBO();
		int page = 1;
		int recordsPerPage = 4;
		int noOfRecords = 0;
		int noOfPages = 0;
		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
			System.out.println("page get = " + page);
		}
		ArrayList<Integer> listPage = new ArrayList<Integer>();
		ArrayList<Film> listFilm;
		listFilm = filmBO.getListFilm((page - 1) * recordsPerPage, recordsPerPage * page);
		
		noOfRecords = FilmDAO.getNoOfRecords();
		noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		for (int i = 1; i <= noOfPages; i++) {
			listPage.add(i);
		}
		listFilmForm.setListFilm(listFilm);
		listFilmForm.setListPage(listPage);
		listFilmForm.setCurrentPage(page);
		listFilmForm.setNoOfPages(noOfPages);
		
		return mapping.findForward("listFilm");
	}
}
