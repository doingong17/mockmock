package action;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.ListFilmForm;
import model.bean.Film;
import model.bo.FilmBO;
import model.dao.FilmDAO;

public class SearchFilmAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ListFilmForm listFilmForm1 = (ListFilmForm) form;
		System.out.println("aaaaa " );
		String action=listFilmForm1.getAction();
		
		/*if(null != action && action.equals("検索")){
			ActionErrors actionErrors = new ActionErrors();
			if(StringProcess.notVaild(listFilmForm1.getLiberationTimeName())){
				actionErrors.add("LiberationTimeError", new ActionMessage("error.LiberationTime.trong"));
			}
			if(StringProcess.checkDayofWeek(listFilmForm1.getFilmDayOfWeek())){
				actionErrors.add("FilmDayOfWeekError", new ActionMessage("error.FilmDayOfWeek.trong"));
			}
			System.out.println("vo loi " );
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("searchFilmError");
			}
		}*/
		if (null != action && action.equals("検索")) {
			System.out.println("vo tim kiem " );
			Film film = new Film();
			String name = listFilmForm1.getFilmName();
			String libe = listFilmForm1.getLiberationTimeName();
			String cha = listFilmForm1.getCharacterName();
			String dayofweek = listFilmForm1.getFilmDayOfWeek();
			String dayofyear = listFilmForm1.getFilmDayOfYear();
			String time = listFilmForm1.getFilmTime();
			System.out.println("ten phim" +name);
			film.setCharacterName(cha);
			film.setFilmName(name);
			film.setLiberationTimeName(libe);
			film.setFilmDayOfWeek(dayofweek);
			film.setFilmDayOfYear(dayofyear);
			film.setFilmTime(time);
			
			FilmBO filmBO = new FilmBO();	
			int page = 1;
			int recordsPerPage = 4;
			int noOfRecords = 0;
			int noOfPages = 0;
			if (request.getParameter("page") != null) {
				page = Integer.parseInt(request.getParameter("page"));
				System.out.println("page get = " + page);
			}
			ArrayList<Integer> listPage = new ArrayList<Integer>();
			ArrayList<Film> listFilm;
			listFilm = filmBO.getSearchFilm(film,(page - 1) * recordsPerPage, recordsPerPage * page);
			
			noOfRecords = FilmDAO.getNoOfRecords();
			noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			for (int i = 1; i <= noOfPages; i++) {
				listPage.add(i);
			}
			listFilmForm1.setListFilm(listFilm);
			listFilmForm1.setListPage(listPage);
			listFilmForm1.setCurrentPage(page);
			listFilmForm1.setNoOfPages(noOfPages);
			return mapping.findForward("searchFilm");
		}
		return mapping.findForward("searchFilm");
	}
}
