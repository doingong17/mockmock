package common;

public class StringProcess {
	public static boolean notVaild(String s){
		if(s=="来ている") return true;
		return false;
	}
	public static boolean checkDayofWeek(String s){
		if(s=="Monday" || s=="Tuesday" || s=="Wednesday" || s=="Thursday" || s=="Friday" || s=="Saturday" || s=="Sunday") return false;
		return true;
	}
}
