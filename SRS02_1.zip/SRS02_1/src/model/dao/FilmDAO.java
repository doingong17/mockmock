package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import com.microsoft.sqlserver.jdbc.SQLServerBlob;

import form.ListFilmForm;
import model.bean.Film;


public class FilmDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Film";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	Statement stmt = null;
	private static int noOfRecords;
	
	/**
	 * Hàm kết nối database
	 */
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	
	/*public ArrayList<Film> getListFilm() {
		connect();
		String sql=	"SELECT n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime "+
					" FROM Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId ";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Film> list = new ArrayList<Film>();
		Film film;
		try {
			while(rs.next()){
				film = new Film();
				film.setFilmName(rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}*/
	public ArrayList<Film> getListFilm(int offset, int noOfRecords) {
		connect();
		String sql = "SELECT * " + " FROM ( SELECT n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime, "+
					" ROW_NUMBER() over (ORDER BY ID ) as ct from  Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId ) "+
					" sub WHERE ( ct > " + offset + " AND ct <= " + noOfRecords + " ) ";
		ArrayList<Film> list = new ArrayList<Film>();
		Film film;
		ResultSet rs;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				film = new Film();
				film.setFilmName(rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}
			rs.close();
			rs = stmt.executeQuery("select count(*) as num from Films");
			if (rs.next())
				this.noOfRecords = rs.getInt("num");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList<Film> getSearchFilm(Film film, int offset, int noOfRecords) {
		connect();
		String filter ="";
		ResultSet rs = null;
		if (!"来ている".equals(film.getLiberationTimeName())){
			filter += " LiberationTimeName = '" + film.getLiberationTimeName() + "'";
		}
		if (!"Doctor-Strange".equals(film.getFilmName())){
			filter += " AND FilmName = '" + film.getFilmName() + "'";
		}
		if (!"Name of character".equals(film.getCharacterName())){
			filter += " AND CharacterName = '" + film.getCharacterName() + "'";
		}
		if (film.getFilmDayOfWeek().trim().length()>0){
			filter += " AND FilmDayOfWeek = '" + film.getFilmDayOfWeek() + "'";
		}
		if (film.getFilmDayOfYear().trim().length()>0){
			filter += " AND FilmDayOfYear = '" + film.getFilmDayOfYear() + "'";
		}
		if (film.getFilmTime().trim().length()>0){
			filter += " AND FilmTime = '" + film.getFilmTime() + "'";
		}
		String sql=	"SELECT * FROM  ( SELECT n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime, "+
					" ROW_NUMBER() over (ORDER BY ID ) as ct from  Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId )  "+
					" sub WHERE " + filter + " AND ( ct > " + offset + " AND ct <= " + noOfRecords + " )";
		System.out.println(sql);
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<Film> list = new ArrayList<Film>();
		try {
			while(rs.next()){
				film = new Film();
				film.setFilmName(rs.getString("FilmName"));
				System.out.println("aaaa"+rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}
			System.out.println("select count(*) as num " +"("+sql+")");
			rs.close();
			rs = stmt.executeQuery("select count(*) as num " +"("+sql+")");
			if (rs.next())
				this.noOfRecords = rs.getInt("num");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/*public ArrayList<Film> getSearchFilm(Film film) {
		connect();
		String filter ="";
		ResultSet rs = null;
		if (!"来ている".equals(film.getLiberationTimeName())){
			filter += " l.LiberationTimeName = '" + film.getLiberationTimeName() + "'";
		}
		if (!"Doctor-Strange".equals(film.getFilmName())){
			filter += " AND FilmName = '" + film.getFilmName() + "'";
		}
		if (!"Name of character".equals(film.getCharacterName())){
			filter += " AND CharacterName = '" + film.getCharacterName() + "'";
		}
		if (film.getFilmDayOfWeek().trim().length()>0){
			filter += " AND FilmDayOfWeek = '" + film.getFilmDayOfWeek() + "'";
		}
		if (film.getFilmDayOfYear().trim().length()>0){
			filter += " AND FilmDayOfYear = '" + film.getFilmDayOfYear() + "'";
		}
		if (film.getFilmTime().trim().length()>0){
			filter += " AND FilmTime = '" + film.getFilmTime() + "'";
		}
		String sql=	"SELECT n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime "+
					" FROM Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId "+
					" WHERE " + filter;
		System.out.println(sql);
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Film> list = new ArrayList<Film>();
		try {
			while(rs.next()){
				film = new Film();
				film.setFilmName(rs.getString("FilmName"));
				System.out.println("aaaa"+rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}*/
	
	/**
	 * Ham lay noOfRecords
	 * 
	 * @return the noOfRecords
	 */
	public static int getNoOfRecords() {
		return noOfRecords;
	}

	/**
	 * Ham gan gia tri cho noOfRecords
	 * 
	 * @param noOfRecords
	 *            the noOfRecords to set
	 */
	public void setNoOfRecords(int noOfRecords) {
		this.noOfRecords = noOfRecords;
	}
}
