package model.bo;

import java.util.ArrayList;

import model.bean.Character;
import model.dao.CharacterDAO;

public class CharacterBO {
	CharacterDAO characterDAO = new CharacterDAO();
	public ArrayList<Character> getListCharacter() {
		return characterDAO.getListCharacter();
	}
}
